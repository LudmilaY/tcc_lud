

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletQuery2
 */
@WebServlet("/ServletQuery2")
public class ServletQuery2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletQuery2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		try
	    {
			//Vai pegar o único campo do segundo Combo Box e vai pedir para o usuário digitar
			String myNeo = request.getParameter("functionality");
			//Vai pegar o que está escrito nos outros campos
			ArrayList< ArrayList< ArrayList<String> > > get_myNeo = new ArrayList< ArrayList< ArrayList<String> > >();
//			get_myNeo = request.getParameter("functionality");
			String get_field2 = request.getParameter("typehere2");
			String get_field3 = request.getParameter("typehere3");
			String get_field4 = request.getParameter("typehere4");
			String get_field5 = request.getParameter("typehere5");
			
			PrintWriter writer = response.getWriter();
			response.setContentType("text/html");
			writer.println("<html>");
			writer.println("<head>");
				writer.println("<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\">");
				writer.println("<title>");
					writer.println("Web Application - Results from the Queries");
				writer.println("</title>");
			writer.println("</head>");
			writer.println("<body>");
//			writer.println(get_field2);
//			writer.println(get_field3);
//			writer.println(get_field4);
//			writer.println(get_field5);
				writer.println("<h2>Web Application - Databases integration</h2>");
				writer.println("<p>");
					writer.println("Click <a href=\"ServletMySQL\">here</a>, if you want to proceed to see the MySQL database structure. <br>");
					writer.println("Click <a href=\"ServletNeo4J\">here</a>, if you want to proceed to see the Neo4J database structure. <br>");
					writer.println("Click <a href=\"ServletFunctionalities\">here</a>, if you want to go back to the functionalities page. <br>");
					writer.println("Click <a href=\"Servlet1\">here</a>, if you want to go back to the main page. <br>");
				writer.println("</p>");
				writer.println("<h4>Result of the"+myNeo+"functionality:</h4>");
				writer.println("<font color=red>"+get_myNeo+"</font><br>");
				get_myNeo = Interconnection.tablesInterconnectionMySQLandNeo4J(get_field2, get_field3, get_field4, get_field5);
				
				for(int i = 0; i < get_myNeo.size(); i++) {
					for(int j = 0; j < get_myNeo.get(i).size(); j++) {
						writer.println(get_myNeo.get(i).get(j).toString()+"<br>");
					}
					writer.println("--------------------------------------"+"<br>");
				}
			writer.println("</body>");
			writer.println("</html>");
				writer.close();
	    }
	    catch(Exception exception)
	    {
	        exception.printStackTrace();    
	    }
	}
	
	

}
