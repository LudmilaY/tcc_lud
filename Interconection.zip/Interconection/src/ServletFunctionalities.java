

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletFunctionalities
 */
@WebServlet("/ServletFunctionalities")
public class ServletFunctionalities extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletFunctionalities() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
//		try {
//			String selected_functionality = request.getParameter("functionalities") ;
//		    PrintWriter writer =  response.getWriter();
//		    response.setContentType("text/html");
//		    writer.println("<h4>Selected Functionality is:</h4>");
//		    writer.println("<br><font color=red>"+selected_functionality+"</font>");
//		    writer.close();
//		    
//	    }
//	    catch(Exception exception)
//	    {
//	        exception.printStackTrace();    
//	    }
//		try
//	    {
//			String selected_fruit = request.getParameter("fruit") ;
//			PrintWriter writer =  response.getWriter();
//			response.setContentType("text/html");
//			writer.println("<h4>Selected Fruit Is :</h4>");
//			writer.println("<br><font color=black>"+selected_fruit+"</font>");
//			writer.close();
//	    }
//	    catch(Exception exception)
//	    {
//	        exception.printStackTrace();    
//	    }
	}
	protected void service (HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();

        //O código HTML dentro do Servlet :)
        out.println("<html>");
        out.println("<head>");
    		out.println("<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\">");
    		out.println("<link rel='stylesheet' type='text/css' href='" + request.getContextPath() + "/style.css' />"); 
    		out.println("<title>");
    			out.println("Web Application - Functionalities");
    		out.println("</title>");
        out.println("</head>");
        out.println("<body>");
        	out.println("<h3>Functionalities of the Web Application</h3>");
        	out.println("<p>");
        		out.println("There are some features that you, as a user, might want to accomplish. You can choose them below:");
        	out.println("</p>");
        	out.println("<p>");
    		//out.println("<form action=\"ServletQuery\", method=\"post\">");
    			out.println("<form action=\"ServletQuery\" method=\"post\">");
	        		out.println("<select name=\"functionalities\" class=\"simple basic\">");
	        	    	out.println("<option value=\"functionality\" selected=\"selected\"></option>");
		        	    out.println("<option value=\"averageVoteMoviesOfActor\">Average movie voting of an actor/actress</option>");
		        	    out.println("<option value=\"averageRevenueMoviesOfActor\">Profitability of an actor/actress</option>");
		        	    out.println("<option value=\"averageVoteMoviesOfDirector\">Average movie voting of a director</option>");
		        	    out.println("<option value=\"averageRevenueMoviesOfDirector\">Revenue from a director's movie(s)</option>");
		        	    out.println("<option value=\"averageProfitMoviesOfDirector\">Profit from a director's movie(s)</option>");
		        	    out.println("<option value=\"popularityOfActor\">Popularity of an actor/actress</option>");
		        	out.println("</select>");
		        	out.println("<div>"); 
		        		//out.println("<input type=\"submit\" value=\"Submit\" />");
		        		out.println("Which data from this query do you want to see?:");
			        		out.println("<input type=\"post\" value=\"\" name=\"typehere\" />");
			        		out.println("<input type=\"submit\" value=\"Submit\" />");
		        	out.println("</div>");
		        out.println("</form><br>");
		        out.println("<p>");
		        out.println("<form action=\"ServletQuery2\" method=\"post\">");
//        		out.println("<select name=\"functionality\" class=\"simple basic\">");
//        	    	out.println("<option value=\"functionality\" selected=\"selected\"></option>");
//	        	    out.println("<option value=\"tablesInterconnectionMySQLandNeo4J\">Query join (MySQL & Neo4J)</option>");
//	        	out.println("</select>");
	        	out.println("<div>");
	        		out.println("Based on the tables(columns) and nodes, which data from this query do you want to see?:<br>");
	        		out.println("<font size=\"2\">P.S.: You can check in the MySQL or the Neo4J structure to fill in the fields with the tables and nodes you want to search."
	        				+ "<br>Attention: This operation is case sensitive.<br></font>");
		        		out.println("<input type=\"post\" value=\"\" name=\"typehere2\" />");
		        		out.println("<input type=\"post\" value=\"\" name=\"typehere3\" />");
		        		out.println("<input type=\"post\" value=\"\" name=\"typehere4\" />");
		        		out.println("<input type=\"post\" value=\"\" name=\"typehere5\" />");
		        		out.println("<input type=\"submit\" value=\"Submit\" />");
	        	out.println("</div>");
	        out.println("</form><br>");
//        	out.println("<form action=\"ServletQuery\" method=\"post\">");
//        		out.println("<table align=\"center\">");
//        			out.println("<tr>");
//        			out.println("<td>Select An Item :</td>");
//        			out.println("<td><select name=\"fruit\">");
//	        			out.println("<option value=\"fruit1\">Mango</option>");
//	        			out.println("<option value=\"fruit2\">Banana</option>");
//	        			out.println("<option value=\"fruit3\">Grape</option>");
//	        			out.println("<option value=\"fruit4\">Apple</option>");
//        			out.println("</select>");
//        			out.println("</td>");
//        			out.println("</tr>");
//        			out.println("<tr>");
//        				out.println("<td><input type=\"submit\" value=\"Send\"></td>");
//        			out.println("</tr>");
//        		out.println("</table>");
//        	out.println("</form>");
        	out.println("</p>");
    		out.println("<p>");
    			out.println("Click <a href=\"ServletMySQL\">here</a>, if you want to proceed to see the MySQL database structure. <br>");
    			out.println("Click <a href=\"ServletNeo4J\">here</a>, if you want  to proceed to see the Neo4J database structure. <br>");
    			out.println("Click <a href=\"Servlet1\">here</a>, if you want to go back to the main page. <br>");
    		out.println("</p>");
//        for(int i=0;i<10;i++)
//        	out.println(i+"<br>");
//        out.println("Primeira servlet");
        out.println("</body>");
        out.println("</html>");
    }

}
