import java.sql.*;
import java.util.ArrayList;

public class MysqlServer {
	
	 public static Statement statement = null;

	 public static void startMySQL() throws ClassNotFoundException
	 {
		 	String driverName = "com.mysql.jdbc.Driver";
	        try {
				Class.forName(driverName);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} // here is the ClassNotFoundException

	        String serverName = "localhost";
	        String mydatabase = "movies_metadata";

	        String username = "admin";
	        String password = "admin4321";

	        try {
	            Connection conn = DriverManager.getConnection(
	                    "jdbc:mysql://"+serverName+":3306/"+mydatabase, username, password);

	            statement = conn.createStatement();

	            System.out.println("Connected to the database!");
	        }
	        catch (Exception e) {
				// TODO: handle exception
			}
		 
	 }
	 
	 static ArrayList<String> getDatabaseTables() throws ClassNotFoundException, SQLException
	 {
		 if(statement == null)
			 startMySQL();
		 String SQL = "show tables;";
		 ResultSet resultSet = statement.executeQuery(SQL);
		 ArrayList<String> tables = new ArrayList<String>();
		 while (resultSet.next()) {
             tables.add(resultSet.getString(1));
         }
		 return tables;
	 }
	 
	 static ArrayList< ArrayList<String> > getDataTable(String table) throws SQLException, ClassNotFoundException{
		 if(statement == null)
			 startMySQL();
		 String SQL = "SELECT * FROM "+table+";";
		 ResultSet resultSet = statement.executeQuery(SQL);
		 ResultSetMetaData rsmd = resultSet.getMetaData();
	     int numberOfColumns = rsmd.getColumnCount();
		 ArrayList< ArrayList<String> > tableInfo = new ArrayList< ArrayList<String> >();
		 while (resultSet.next()) {
			 ArrayList<String> linha = new ArrayList<String>();
			 for(int i=1;i<numberOfColumns;i++) {
				 linha.add(resultSet.getString(i));
				 //System.out.println(linha.get(linha.size()-1));
			 }
			 tableInfo.add(linha);
         }
		 return tableInfo;
	 }
	 
	 static ArrayList< ArrayList<String> > getDataSQL(String SQL) throws SQLException, ClassNotFoundException{
		 if(statement == null)
			 startMySQL();
		 //String SQL = "SELECT * FROM "+table+";";
		 ResultSet resultSet = statement.executeQuery(SQL);
		 ResultSetMetaData rsmd = resultSet.getMetaData();
	     int numberOfColumns = rsmd.getColumnCount();
		 ArrayList< ArrayList<String> > tableInfo = new ArrayList< ArrayList<String> >();
		 while (resultSet.next()) {
			 ArrayList<String> linha = new ArrayList<String>();
			 for(int i=1;i<numberOfColumns;i++) {
				 linha.add(resultSet.getString(i));
				 //System.out.println(linha.get(linha.size()-1));
			 }
			 tableInfo.add(linha);
         }
		 return tableInfo;
	 }
	 
	 static ArrayList< ArrayList<String> > describeTable(String table) throws SQLException, ClassNotFoundException{
		 if(statement == null)
			 startMySQL();
		 String SQL = "describe "+table+";";
		 ResultSet resultSet = statement.executeQuery(SQL);
		 ResultSetMetaData rsmd = resultSet.getMetaData();
	     int numberOfColumns = rsmd.getColumnCount();
		 //System.out.print(numberOfColumns);
		 ArrayList< ArrayList<String> > tableInfo = new ArrayList< ArrayList<String> >();
		 while (resultSet.next()) {
			 ArrayList<String> linha = new ArrayList<String>();
			 for(int i=1;i<numberOfColumns;i++) {
				 //System.out.println(resultSet.getString(i));
				 linha.add(resultSet.getString(i));
			 }
			 tableInfo.add(linha);
         }
		 return tableInfo;
	 }
	 
	 public static ArrayList<String> listFildsTable(String table) throws ClassNotFoundException, SQLException{
		 ArrayList< ArrayList<String> > describle =  describeTable(table);
		 ArrayList<String> colluns = new ArrayList<String>();
		 for(int i=0;i<describle.size();i++) {
			 //System.out.println(describle.get(i).get(0));
			 colluns.add(describle.get(i).get(0));			 
		 }
		 return colluns;
	 }
	 
	 public static void main(String[] args) throws SQLException, ClassNotFoundException {
		 System.out.println(getDatabaseTables());
		 System.out.println(getDataTable("people"));
		 System.out.println(describeTable("people"));
		 System.out.println(listFildsTable("people"));
		 System.out.println(getDataSQL("select * from people where name=\"Gena Rowlands\";"));
	 }


}
