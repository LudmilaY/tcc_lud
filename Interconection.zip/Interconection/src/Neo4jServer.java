import java.sql.SQLException;
import java.util.ArrayList;


import org.neo4j.driver.v1.AuthTokens;
import org.neo4j.driver.v1.Driver;
import org.neo4j.driver.v1.GraphDatabase;
import org.neo4j.driver.v1.Session;
import org.neo4j.driver.v1.StatementResult;


public class Neo4jServer {
	
	public static Driver driver = null;
	
	public static void neo4jConnection() {
		driver = GraphDatabase.driver("bolt://localhost:7687", AuthTokens.basic("neo4j", "password"));
	}
	
	public void close() throws Exception {
        driver.close();
    }
	
	
	public static ArrayList< ArrayList<String> > getNodeData(String node)
    {
		if(driver == null)
			neo4jConnection();
		
		ArrayList<String> nodeInfo = getNodeFields(node);
		ArrayList< ArrayList<String> > data = new ArrayList< ArrayList<String> >();
        try ( Session session = driver.session() )
        {
        	String cypherQuery  = "match(p:"+node+") return p";
        	StatementResult result = session.run( cypherQuery);
      
        	while (result.hasNext()) {
        	    //nodeList.add(result.next().fields().get(0).value().asMap());
        	    String info = result.next().fields().get(0).value().asMap().toString();
        	    ArrayList<String> aux = new ArrayList<String>();
        	    
        	    //System.out.println(data.get(data.size()-1));
        	    //ordenando a ordem de entrada do vetor como a ordem de exibição de informação dos campos
        	    for(int i=0;i<nodeInfo.size();i++) {
        	    	String field = "";
        	    	if(info.indexOf(nodeInfo.get(i)) != -1) {
        	    		field = info.substring(info.indexOf(nodeInfo.get(i))+nodeInfo.get(i).length()+1, info.length()-1);
        	    		if(field.indexOf(",") != -1)
        	    			field = field.substring(0, field.indexOf(","));
        	    		
        	    		//System.out.println(field);
        	    	}
        	    	aux.add(field);
        	    	//System.out.println(field);
        	    }
        	    data.add(aux);
        	}
        	//return nodeList;
        }
        return data;
    }
	
	public static ArrayList<String> getNodeFields(String node){
		if(driver == null)
			neo4jConnection();
		
		ArrayList<String> data = new ArrayList<String>();
        try ( Session session = driver.session() )
        {
        	String cypherQuery  = "MATCH (n:"+node+")\n" + 
        			"RETURN labels(n), keys(n), size(keys(n)), count(*)\n";
        	//System.out.println(cypherQuery);
        	StatementResult result = session.run(cypherQuery);
        	
        	String info = result.list().get(0).toString();
        	info = info.substring(info.indexOf("keys(n): [\"")+10);
        	info = info.substring(0, info.indexOf("]"));
        	StringBuilder sb = new StringBuilder(info);
        	//remove '"' (aspas duplas)
        	while(info.indexOf('"') != -1) {
        		sb = sb.deleteCharAt(info.indexOf('"'));
        		info = sb.toString();
        	}
        	//remove ' ' (espaço)
        	while(info.indexOf(' ') != -1) {
        		sb = sb.deleteCharAt(info.indexOf(' '));
        		info = sb.toString();
        	}
        	String[] array = info.split(",");
        	for(int i=0;i<array.length;i++) {
        		//System.out.println(array[i]);
        		data.add(array[i]);
        	}
        	//return nodeList;
        }
        return data;
	}
	
	
	public static ArrayList<ArrayList<String>> getRelationshipData(String relationship){
		if(driver == null)
			neo4jConnection();
		
		ArrayList< ArrayList<String> > data = new ArrayList< ArrayList<String> >();
        try ( Session session = driver.session() )
        {
        	String cypherQuery = "MATCH p=()-[r:"+relationship+"]->() RETURN p";
        	StatementResult result = session.run(cypherQuery);
        	
        	while (result.hasNext()) {
        	    //nodeList.add(result.next().fields().get(0).value().asMap());
        		ArrayList<String> dataInfo = new ArrayList<String>();
        		String info = result.next().get("p").toString();
        	    String aux = info.substring(info.indexOf("(")+1, info.indexOf(")"));
        	    dataInfo.add(aux);
        	    info = info.substring(info.indexOf("(")+1,info.length());
        	    aux = info.substring(info.indexOf("[")+1, info.indexOf(":"));
        	    dataInfo.add(aux);
        	    info = info.substring(info.indexOf("[")+1,info.length());
        	    aux = info.substring(info.indexOf("(")+1, info.indexOf(")"));
        	    dataInfo.add(aux);
        	    data.add(dataInfo);
        	}
        	//return nodeList;
        }
        return data;
	}
	
	public static ArrayList<String> getElementById(String id, String node){
		if(driver == null)
			neo4jConnection();
		ArrayList<String> nodeInfo = getNodeFields(node);
		String sql = "MATCH (s) WHERE ID(s) = "+id+" RETURN s";
		ArrayList<String> aux = new ArrayList<String>();
		try ( Session session = driver.session() )
        {
        	String cypherQuery = sql;
        	StatementResult result = session.run(cypherQuery);
            String info = result.next().fields().get(0).value().asMap().toString();
        	//System.out.println(info);
        	
        	for(int i=0;i<nodeInfo.size();i++) {
        	    String field = "";
        	    if(info.indexOf(nodeInfo.get(i)) != -1) {
        	    	field = info.substring(info.indexOf(nodeInfo.get(i))+nodeInfo.get(i).length()+1, info.length()-1);
        	    	if(field.indexOf(",") != -1)
        	    		field = field.substring(0, field.indexOf(","));
        	    		
        	    		//System.out.println(field);
        	    }
        	    aux.add(field);
        	}    
        }
        return aux;
	}
	
	
	public static ArrayList<String> getNodes(){
		if(driver == null)
			neo4jConnection();
		
		ArrayList<String> data = new ArrayList<String>();
        try ( Session session = driver.session() )
        {
        	String cypherQuery  = "MATCH (n) RETURN labels(n), count(*)";
        	//System.out.println(cypherQuery);
        	StatementResult result = session.run(cypherQuery);
        
        	String info = result.list().toString();
        	while(info.indexOf("[\"") != -1) {
        		info = info.substring(info.indexOf("[\"")+2);
        		String node = info.substring(0,info.indexOf("\""));
        		//System.out.println(node);
        		data.add(node);
        	}
        }
        return data;
	}
	
	public static ArrayList<String> getRelationshipsList(){
		if(driver == null)
			neo4jConnection();
		
		ArrayList<String> data = new ArrayList<String>();
        try ( Session session = driver.session() )
        {
        	String cypherQuery  = "MATCH (n)-[r]-(m) RETURN type(r), count(r)";
        	//System.out.println(cypherQuery);
        	StatementResult result = session.run(cypherQuery);
               	
        	String info = result.list().toString();
        	//System.out.println(info);
        	while(info.indexOf('"') != -1) {
        		info = info.substring(info.indexOf('"')+1);
        		String node = "";
       			node = info.substring(0,info.indexOf('"'));
        		//System.out.println(node);
        		info = info.substring(info.indexOf('"')+1,info.length());
        		data.add(node);
        	}
        }
        return data;
	}
	
	
	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		neo4jConnection();
		
		System.out.println(getNodeData("Person"));
		System.out.println(getNodeFields("Movie"));
		System.out.println(getNodes());
		System.out.println(getRelationshipsList());
		System.out.println(getRelationshipData("ACTED_IN"));
		System.out.println(getElementById("1","Person"));
	}
}
