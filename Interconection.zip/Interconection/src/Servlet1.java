import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Servelet1
 */
@WebServlet("/Servlet1")
public class Servlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlet1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("UTF-8");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.sendRedirect("index.jsp");

	}

	protected void service (HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();

        //O código HTML dentro do Servlet :)
        out.println("<html>");
        out.println("<head>");
    		out.println("<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\">");
    		out.println("<title>");
    			out.println("Web Application - Integration and Connection");
    		out.println("</title>");
        out.println("</head>");
        out.println("<body>");
        	out.println("<h2>Web Application - Databases integration</h2>");
        	out.println("<p>");
        		out.println("This application provides to the user a new way to do data integration. <br>");
        		out.println("The databases used are relative to bases (relational and graph) that are related to movies, actors, awards, directors and their possible relationships. <br>");
        		out.println("There are some requirements that must be settled before use it:");
        		out.println("<ol>");
        			out.println("<li>");
        				out.println("The MySQL server must be started with username and password<a href=\"#1st\">[1]</a>.");
        			out.println("</li>");
        			out.println("<li>");
    					out.println("The Neo4J server must be started with username and password<a href=\"#2nd\">[2]</a>.");
    				out.println("</li>");
        		out.println("</ol>");
        	out.println("</p>");
        	out.println("<p id=\"1st\"><font size=\"2\">");
        		out.println("[1]Which is, in this case, respectively: 'admin' and 'admin4321'.");
        	out.println("</font></p>");
        	out.println("<p id=\"2nd\"><font size=\"2\">");
    			out.println("[2]Which is, in this case, respectively: 'neo4j' and 'password'.");
    		out.println("</font></p>");
    		out.println("<p>");
    			out.println("Click <a href=\"ServletMySQL\">here</a> to proceed to see the MySQL database structure. <br>");
    			out.println("Click <a href=\"ServletNeo4J\">here</a> to proceed to see the Neo4J database structure. <br>");
    			out.println("Click <a href=\"ServletFunctionalities\">here</a> to proceed to use the functionalities of this application. <br>");
    		out.println("</p>");
//        for(int i=0;i<10;i++)
//        	out.println(i+"<br>");
//        out.println("Primeira servlet");
        out.println("</body>");
        out.println("</html>");
    }
}
