

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletResult
 */
@WebServlet("/ServletQuery")
public class ServletQuery extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletQuery() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		try
	    {
			//Esse primeiro vai pegar a funcionalidade escolhida no primeiro Combo Box
			String selected_functionality = request.getParameter("functionalities");
			//Vai pegar o que o usuário digitar no field relativo a pesquisa do 1º Combo Box
			String get_field = request.getParameter("typehere");
			//Vai pegar o único campo do segundo Combo Box e vai pedir para o usuário digitar
			String myNeo = request.getParameter("functionality");
			//Vai pegar o que está escrito nos outros campos
			ArrayList< ArrayList< ArrayList<String> > > get_myNeo = new ArrayList< ArrayList< ArrayList<String> > >();
//			get_myNeo = request.getParameter("functionality");
			String get_field2 = request.getParameter("typehere2");
			String get_field3 = request.getParameter("typehere3");
			String get_field4 = request.getParameter("typehere4");
			String get_field5 = request.getParameter("typehere5");
			
			PrintWriter writer = response.getWriter();
			response.setContentType("text/html");
			writer.println("<html>");
			writer.println("<head>");
				writer.println("<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\">");
				writer.println("<title>");
					writer.println("Web Application - Results from the Queries");
				writer.println("</title>");
			writer.println("</head>");
			writer.println("<body>");
				writer.println("<h2>Web Application - Databases integration</h2>");
				writer.println("<p>");
					writer.println("Click <a href=\"ServletMySQL\">here</a>, if you want to proceed to see the MySQL database structure. <br>");
					writer.println("Click <a href=\"ServletNeo4J\">here</a>, if you want to proceed to see the Neo4J database structure. <br>");
					writer.println("Click <a href=\"ServletFunctionalities\">here</a>, if you want to go back to the functionalities page. <br>");
					writer.println("Click <a href=\"Servlet1\">here</a>, if you want to go back to the main page. <br>");
				writer.println("</p>");
				writer.println("<h4>Selected Functionality is:</h4>");
				writer.println("<font color=red>"+selected_functionality+"</font><br>");
				writer.println("<h4>Result of the"+selected_functionality+"functionality:</h4>");
				writer.println("<font color=red>"+get_field+"</font><br>");
				writer.println("<h4>Result of the"+myNeo+"functionality:</h4>");
				writer.println("<font color=red>"+get_myNeo+"</font><br>");
				//Os "if's" para verificar se somente o campo de cima que foi utilizado
				if(selected_functionality.equals("averageVoteMoviesOfActor")) {
					try {
						get_field = Interconnection.averageVoteMoviesOfActor(get_field).toString();
					} catch (ClassNotFoundException | SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					writer.println("<font color=\"blue\">"+get_field+"<br>");
					
				}
				if(selected_functionality.equals("averageRevenueMoviesOfActor")) {
					try {
						get_field = Interconnection.averageRevenueMoviesOfActor(get_field).toString();
					} catch (ClassNotFoundException | SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					writer.println("<font color=blue>"+get_field+"<br>");
					
				}
				if(selected_functionality.equals("averageVoteMoviesOfDirector")) {
					try {
						get_field = Interconnection.averageVoteMoviesOfDirector(get_field).toString();
					} catch (ClassNotFoundException | SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					writer.println("<font color=blue>"+get_field+"<br>");
					
				}
				if(selected_functionality.equals("averageRevenueMoviesOfDirector")) {
					try {
						get_field = Interconnection.averageRevenueMoviesOfDirector(get_field).toString();
					} catch (ClassNotFoundException | SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					writer.println("<font color=blue>"+get_field+"<br>");
					
				}
				if(selected_functionality.equals("averageProfitMoviesOfDirector")) {
					try {
						get_field = Interconnection.averageProfitMoviesOfDirector(get_field).toString();
					} catch (ClassNotFoundException | SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					writer.println("<font color=blue>"+get_field+"<br>");
					
				}
				if(selected_functionality.equals("popularityOfActor")) {
					try {
						get_field = Interconnection.popularityOfActor(get_field).toString();
					} catch (ClassNotFoundException | SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					writer.println("<font color=blue>"+get_field+"<br>");
					
				}
				if(selected_functionality.equals("averageVoteMoviesOfActor")) {
					try {
						get_field = Interconnection.averageVoteMoviesOfActor(get_field).toString();
					} catch (ClassNotFoundException | SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					writer.println("<font color=blue>"+get_field+"<br>");
				}
//				if(myNeo.equals("tablesInterconnectionMySQLandNeo4J")) {
//					try {
//						get_myNeo = Interconnection.tablesInterconnectionMySQLandNeo4J(get_field2, get_field3, get_field4, get_field5).toString();
//					} catch (ClassNotFoundException | SQLException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
//					writer.println("<font color=blue>"+get_myNeo+"<br>");
//				}
			writer.println("</body>");
			writer.println("</html>");
				writer.close();
	    }
	    catch(Exception exception)
	    {
	        exception.printStackTrace();    
	    }
	}
	//FOI COMENTADO ISSO AÍ EMBAIXO PORQUE O SERVICE TAVA SOBREPONDO O DOPOST
	/*
	protected void service (HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();

        //O código HTML dentro do Servlet :)
        out.println("<html>");
        out.println("<head>");
    		out.println("<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\">"); 
    		out.println("<title>");
    			out.println("Web Application - Results");
    		out.println("</title>");
        out.println("</head>");
        out.println("<body>");
        	out.println("<h3>Result of the choosed query</h3>");
        	out.println("<p>");
				out.println("Click <a href=\"ServletMySQL\">here</a>, if you want to proceed to see the MySQL database structure. <br>");
				out.println("Click <a href=\"ServletNeo4J\">here</a>, if you want  to proceed to see the Neo4J database structure. <br>");
				out.println("Click <a href=\"Servlet1\">here</a>, if you want to go back to the main page. <br>");
			out.println("</p>");
        	out.println("<p>");
        		out.println("Results below:");
        	out.println("</p>");
        	out.println("<p>");
        		out.println("DEU CERTO");
        	out.println("</p>");
//        for(int i=0;i<10;i++)
//        	out.println(i+"<br>");
//        out.println("Primeira servlet");
        out.println("</body>");
        out.println("</html>");
    }
*/
}
