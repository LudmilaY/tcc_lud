import java.sql.SQLException;
import java.util.ArrayList;

public class Interconnection {

	public static ArrayList< ArrayList< ArrayList<String> > > tablesInterconnectionMySQLandNeo4J(String table, String collun, String node, String info) throws ClassNotFoundException, SQLException {
		//carregando os dados na memória e as tabelas de informação na ordem dos dados
		//ArrayList< ArrayList<String> > tableData = MysqlServer.getDataTable(table);
		ArrayList< ArrayList<String> > nodeData = Neo4jServer.getNodeData(node);
		ArrayList<String> collInfo = MysqlServer.listFildsTable(table);
		ArrayList<String> dataNode = Neo4jServer.getNodeFields(node);
		//pegando o indice em cada tabela para saber qual elemento comparar em cada tabela
		int indexColl;
		for(indexColl=0;indexColl<collInfo.size();indexColl++) {
			if(collInfo.get(indexColl).equals(collun)) {
				break;
			}
		}
		int indexData;
		for(indexData=0;indexData<dataNode.size();indexData++) {
			if(dataNode.get(indexData).equals(info)) {
				break;
			}
		}

		//Se o elemento escolhido em uma tabela for igual ao elemento 
		//escolhido na outra tabela, ambos serão adicionados a lista de 
		//encontros para serem retornados
		ArrayList< ArrayList< ArrayList<String> > > mergeTable = new ArrayList< ArrayList< ArrayList<String> > >();
		
		
		for(int i=0;i<nodeData.size();i++) {
			//System.out.println("select * from "+table+" where "+collInfo.get(indexColl)+"='"+nodeData.get(i).get(indexData)+"';");
			
			try {
				String SQL = "select * from "+table+" where "+collInfo.get(indexColl)+"='"+nodeData.get(i).get(indexData)+"';";
				ArrayList< ArrayList<String> > searchSQL = MysqlServer.getDataSQL(SQL);			
				
				if(searchSQL.size()>0) {
					ArrayList< ArrayList<String> > aux = new ArrayList< ArrayList<String> >();
					aux.add(nodeData.get(i));
					aux.addAll(searchSQL);
					mergeTable.add(aux);
				}
			}
			catch(Exception e){
				
			}
		}
		return mergeTable;	
 	}
	
	public static Double averageVoteMoviesOfActor(String actor_name) throws ClassNotFoundException, SQLException{
		
		ArrayList< ArrayList<String> > ACTED_IN = Neo4jServer.getRelationshipData("ACTED_IN");
		ArrayList< ArrayList<String> > movies = new ArrayList< ArrayList<String> >();
		for(int i=0;i<ACTED_IN.size();i++) {
			ArrayList<String> actor = Neo4jServer.getElementById(ACTED_IN.get(i).get(0), "Person");
			if(actor.get(1).equals(actor_name)) {
				movies.add(Neo4jServer.getElementById(ACTED_IN.get(i).get(2), "Movie"));
			}
		}
		double valueTotal=0,count=0;
		
		for(int i=0;i<movies.size();i++) {
			String sql = "select * from movie where title=\""+movies.get(i).get(0)+"\";"; 
			//System.out.println(sql);

			ArrayList< ArrayList<String> > dataMovie =  MysqlServer.getDataSQL(sql);
			if(dataMovie.size()>0) {
				//moviesRD.addAll(dataMovie);
				//System.out.println(dataMovie.get(0).get(17));
				valueTotal += Float.parseFloat(dataMovie.get(0).get(17))*Float.parseFloat(dataMovie.get(0).get(18)); 
				count += (int)Float.parseFloat(dataMovie.get(0).get(18)); 
			}
		}
		//System.out.println(moviesRD);
		return valueTotal/count;
	}
	
	
	public static Double averageRevenueMoviesOfActor(String actor_name) throws ClassNotFoundException, SQLException{
		
		ArrayList< ArrayList<String> > ACTED_IN = Neo4jServer.getRelationshipData("ACTED_IN");
		ArrayList< ArrayList<String> > movies = new ArrayList< ArrayList<String> >();
		for(int i=0;i<ACTED_IN.size();i++) {
			ArrayList<String> actor = Neo4jServer.getElementById(ACTED_IN.get(i).get(0), "Person");
			if(actor.get(1).equals(actor_name)) {
				movies.add(Neo4jServer.getElementById(ACTED_IN.get(i).get(2), "Movie"));
			}
		}
		double valueTotal=0,count=0;
		
		for(int i=0;i<movies.size();i++) {
			String sql = "select * from movie where title=\""+movies.get(i).get(0)+"\";"; 
			//System.out.println(sql);

			ArrayList< ArrayList<String> > dataMovie =  MysqlServer.getDataSQL(sql);
			if(dataMovie.size()>0) {
				//moviesRD.addAll(dataMovie);
				//System.out.println(dataMovie.get(0).get(11));
				valueTotal += Float.parseFloat(dataMovie.get(0).get(11)); 
				count += 1; 
			}
		}
		//System.out.println(moviesRD);
		return valueTotal/count;
	}
	
	public static Double averageVoteMoviesOfDirector(String director_name) throws ClassNotFoundException, SQLException{
		
		ArrayList< ArrayList<String> > DIRECTED = Neo4jServer.getRelationshipData("DIRECTED");
		ArrayList< ArrayList<String> > movies = new ArrayList< ArrayList<String> >();
		for(int i=0;i<DIRECTED.size();i++) {
			ArrayList<String> director = Neo4jServer.getElementById(DIRECTED.get(i).get(0), "Person");
			if(director.get(1).equals(director_name)) {
				movies.add(Neo4jServer.getElementById(DIRECTED.get(i).get(2), "Movie"));
			}
		}
		double valueTotal=0,count=0;
		
		for(int i=0;i<movies.size();i++) {
			String sql = "select * from movie where title=\""+movies.get(i).get(0)+"\";"; 
			//System.out.println(sql);

			ArrayList< ArrayList<String> > dataMovie =  MysqlServer.getDataSQL(sql);
			if(dataMovie.size()>0) {
				//moviesRD.addAll(dataMovie);
				//System.out.println(dataMovie.get(0).get(11));
				valueTotal += Float.parseFloat(dataMovie.get(0).get(17))*Float.parseFloat(dataMovie.get(0).get(18)); 
				count += (int)Float.parseFloat(dataMovie.get(0).get(18)); 

			}
		}
		//System.out.println(moviesRD);
		return valueTotal/count;
	}
	
	public static Double averageRevenueMoviesOfDirector(String director_name) throws ClassNotFoundException, SQLException{
			
			ArrayList< ArrayList<String> > DIRECTED = Neo4jServer.getRelationshipData("DIRECTED");
			ArrayList< ArrayList<String> > movies = new ArrayList< ArrayList<String> >();
			for(int i=0;i<DIRECTED.size();i++) {
				ArrayList<String> director = Neo4jServer.getElementById(DIRECTED.get(i).get(0), "Person");
				if(director.get(1).equals(director_name)) {
					movies.add(Neo4jServer.getElementById(DIRECTED.get(i).get(2), "Movie"));
				}
			}
			double valueTotal=0,count=0;
			for(int i=0;i<movies.size();i++) {
				String sql = "select * from movie where title=\""+movies.get(i).get(0)+"\";"; 
				//System.out.println(sql);
	
				ArrayList< ArrayList<String> > dataMovie =  MysqlServer.getDataSQL(sql);
				if(dataMovie.size()>0) {
					//moviesRD.addAll(dataMovie);
					//System.out.println(dataMovie.get(0).get(11));
					valueTotal += Float.parseFloat(dataMovie.get(0).get(11)); 
					count += 1; 
				}
			}
			return valueTotal/count;
		}
		
	
	public static Double averageProfitMoviesOfDirector(String director_name) throws ClassNotFoundException, SQLException{
		
		ArrayList< ArrayList<String> > DIRECTED = Neo4jServer.getRelationshipData("DIRECTED");
		ArrayList< ArrayList<String> > movies = new ArrayList< ArrayList<String> >();
		for(int i=0;i<DIRECTED.size();i++) {
			ArrayList<String> director = Neo4jServer.getElementById(DIRECTED.get(i).get(0), "Person");
			if(director.get(1).equals(director_name)) {
				movies.add(Neo4jServer.getElementById(DIRECTED.get(i).get(2), "Movie"));
			}
		}
		double valueTotal=0,count=0;
		for(int i=0;i<movies.size();i++) {
			String sql = "select * from movie where title=\""+movies.get(i).get(0)+"\";"; 
			//System.out.println(sql);
	
			ArrayList< ArrayList<String> > dataMovie =  MysqlServer.getDataSQL(sql);
			if(dataMovie.size()>0) {
				//moviesRD.addAll(dataMovie);
				//System.out.println(dataMovie.get(0).get(11));
				valueTotal += Float.parseFloat(dataMovie.get(0).get(11)) - Float.parseFloat(dataMovie.get(0).get(1)); 
				count += 1; 
			}
		}
		return valueTotal/count;
	}
		
	public static Double popularityOfActor(String actor_name) throws ClassNotFoundException, SQLException{
		
		ArrayList< ArrayList<String> > ACTED_IN = Neo4jServer.getRelationshipData("ACTED_IN");
		ArrayList< ArrayList<String> > movies = new ArrayList< ArrayList<String> >();
		for(int i=0;i<ACTED_IN.size();i++) {
			ArrayList<String> actor = Neo4jServer.getElementById(ACTED_IN.get(i).get(0), "Person");
			if(actor.get(1).equals(actor_name)) {
				movies.add(Neo4jServer.getElementById(ACTED_IN.get(i).get(2), "Movie"));
			}
		}
		double valueTotal=0,count=0;
		
		for(int i=0;i<movies.size();i++) {
			String sql = "select * from movie where title=\""+movies.get(i).get(0)+"\";"; 
			//System.out.println(sql);

			ArrayList< ArrayList<String> > dataMovie =  MysqlServer.getDataSQL(sql);
			if(dataMovie.size()>0) {
				//moviesRD.addAll(dataMovie);
				//System.out.println(dataMovie.get(0).get(17));
				valueTotal += Float.parseFloat(dataMovie.get(0).get(8)); 
				count += 1; 
			}
		}
		//System.out.println(moviesRD);
		return valueTotal/count;
	}
	
	
		/*
		
		  
	@app.route('/bestprofitadpartnership', methods=['GET'])
	def best_profit_ad_partnership():
	    q = 'MATCH (a:Actor)-[r:ACTS_IN]->(m:Movie)<-[:DIRECTED]-(b:Director) RETURN m.imdbId, a.name, a.id, b.id, b.name'
	    results = db.query(q, returns=(str, str, int, int, str))
	    rdd = sc.parallelize(results)
	    schema = StructType([StructField('imdbId', StringType(), True),
	                         StructField('name_actor', StringType(), True),
	                         StructField('actor_id', IntegerType(), True),
	                         StructField('director_id', IntegerType(), True),
	                         StructField('name_director', StringType(), True),
	                         ])
	        
	    df = sqlContext.createDataFrame(rdd, schema)
	    dfj = df.join(dfpostgres, df.imdbId == dfpostgres.imdb_id)
	    best = dfj.groupby('actor_id','name_actor', 'director_id', 'name_director').agg({'revenue': 'sum'})
	    best = best.sort(desc('sum(revenue)'))
	    mean = {}
	    mean["actor_id"] = best.rdd.map(tuple).take(2)[1][0]
	    mean["name_actor"] = best.rdd.map(tuple).take(2)[1][1]
	    mean["director_id"] = best.rdd.map(tuple).take(2)[1][2]
	    mean["name_director"] = best.rdd.map(tuple).take(2)[1][3]
	    mean["revenue"] = best.rdd.map(tuple).take(2)[1][4]
	    
	    
	    return json.dumps(mean, indent=4, separators=(',', ': '))
	    
	@app.route('/bestcriticalaapartnership', methods=['GET'])
	def best_critical_aa_partnership():
	    q = 'MATCH (a:Actor)-[:ACTS_IN]->(m:Movie)<-[:ACTS_IN]-(b:Actor) RETURN m.imdbId, a.name, a.id, b.id, b.name'
	    results = db.query(q, returns=(str, str, int, int, str))
	    rdd = sc.parallelize(results)
	    schema = StructType([StructField('imdbId', StringType(), True),
	                         StructField('name_actor1', StringType(), True),
	                         StructField('actor1_id', IntegerType(), True),
	                         StructField('actor2_id', IntegerType(), True),
	                         StructField('name_actor2', StringType(), True),
	                         ])
	        
	    df = sqlContext.createDataFrame(rdd, schema)
	    dfj = df.join(dfpostgres, df.imdbId == dfpostgres.imdb_id)
	    best = dfj.filter(col('vote_average') < 10).groupby('actor1_id','name_actor1', 'actor2_id', 'name_actor2').agg({'vote_average': 'mean','imdbId': 'count'})
	    best = best.sort(desc('count(imdbId)'), desc('avg(vote_average)'))
	    mean = {}
	    mean["actor1_id"] = best.rdd.map(tuple).take(2)[1][0]
	    mean["name_actor1"] = best.rdd.map(tuple).take(2)[1][1]
	    mean["actor2_id"] = best.rdd.map(tuple).take(2)[1][2]
	    mean["name_actor2"] = best.rdd.map(tuple).take(2)[1][3]
	    mean["vote_average"] = best.rdd.map(tuple).take(2)[1][5]
	    mean["count_movies"] = best.rdd.map(tuple).take(2)[1][4]
	    
	    
	    return json.dumps(mean, indent=4, separators=(',', ': '))
	
	*/
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		//System.out.println(tablesInterconnectionMySQLandNeo4J("people", "name", "Person", "name"));
		//System.out.println(averageVoteMoviesOfActor("Keanu Reeves"));
		//System.out.println(averageRevenueMoviesOfActor("Keanu Reeves"));
		//System.out.println(averageVoteMoviesOfDirector("Lilly Wachowski"));
		//System.out.println(averageRevenueMoviesOfDirector("Lilly Wachowski"));
		//System.out.println(averageProfitMoviesOfDirector("Lilly Wachowski"));
		//System.out.println(popularityOfActor("Keanu Reeves"));
		
	}

}
